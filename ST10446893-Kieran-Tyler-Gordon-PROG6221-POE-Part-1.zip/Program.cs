﻿using System;
using System.Media;
using System.Threading;
using System.IO;
using NAudio.Wave;

class CyberSecurityBot
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8; PlayGreeting(); ShowAsciiArt();

        string userName;
        do
        {
            Console.Write("Enter your name: ");
            userName = Console.ReadLine().Trim();
        } while (string.IsNullOrEmpty(userName));

        Console.WriteLine($"\n[CyberSecurity Bot] Hello {userName}, ask me cybersecurity-related questions. Type 'exit' to quit.");

        while (true)
        {
            Console.Write("\nYou: ");
            string input = Console.ReadLine().ToLower().Trim();

            if (input == "exit")
            {
                //Goodbye greeting 
                Console.WriteLine($"\n[CyberSecurity Bot] Stay safe on the web {userName}, see you soon.");
                break;
            }

            ProvideCyberSecurityInfo(input);
        }
    }

    static void PlayGreeting()
    {
        string path = "greeting.wav";

        if (File.Exists(path))
        {
            using (var audioFile = new AudioFileReader(path))
            using (var outputDevice = new WaveOutEvent())
            {
                outputDevice.Init(audioFile);
                outputDevice.Play();
                while (outputDevice.PlaybackState == PlaybackState.Playing)
                {
                    System.Threading.Thread.Sleep(100);
                }
            }
        }
        else
        {
            Console.WriteLine("Warning: Sound file not found. Skipping greeting sound...");
        }
    }

    static void ShowAsciiArt()
    {
        Console.WriteLine(@" 
  

.----------------. | CYBER BOT | '----------------' .--------. | [o] [o] | 

 | ------ | 

 | ______/ | '--------' ");
    }

    static void ProvideCyberSecurityInfo(string question)
    {
        Console.Write("[CyberSecurity Bot] ");
        Thread.Sleep(500);

        switch (question)
        {
            case "password safety":
                Console.WriteLine("Use strong, uniquely created passwords and always enable two-factor authentication.");
                break;
            case "phishing":
                Console.WriteLine("Avoid clicking on any suspicious links, whether it be from an entity that should be trusted or not and verify email senders.");
                break;
            case "public wifi":
                Console.WriteLine("Avoid using public Wi-Fi for sensitive or private activity.");
                break;
            case "software updates":
                Console.WriteLine("Always update your software to resolve security vulnerabilities.");
                break;
            default:
                Console.WriteLine("I'll only answer your cybersecurity-related questions.");
                break;
        }
    }


}
